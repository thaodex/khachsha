import { useEffect, useState } from "react";
import { Toaster } from "./components/ui/sonner";
import { StoreProvider, useStore } from "./lib/store";
import { Login } from "./components/Login";
import { PublicSite } from "./components/PublicSite";
import { Layout, PageKey, canAccess, NAV } from "./components/Layout";
import { Dashboard } from "./components/pages/Dashboard";
import { RoomCalendar } from "./components/pages/RoomCalendar";
import { Availability } from "./components/pages/Availability";
import { Bookings } from "./components/pages/Bookings";
import { Customers } from "./components/pages/Customers";
import { Rooms } from "./components/pages/Rooms";
import { Services } from "./components/pages/Services";
import { Invoices } from "./components/pages/Invoices";
import { Statistics } from "./components/pages/Statistics";
import { AIAssistant } from "./components/pages/AIAssistant";
import { Requests } from "./components/pages/Requests";
import { BookingPortal } from "./components/pages/BookingPortal";
import { RevenueAI } from "./components/pages/RevenueAI";
import { Reviews } from "./components/pages/Reviews";
import { Channels } from "./components/pages/Channels";
import { Loyalty } from "./components/pages/Loyalty";
import { Operations } from "./components/pages/Operations";
import { Profile } from "./components/pages/Profile";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { I18nProvider } from "./lib/i18n";

const TITLES: Record<PageKey, { title: string; subtitle: string }> = {
  dashboard: { title: "Tổng quan", subtitle: "Bức tranh hoạt động khách sạn hôm nay" },
  portal: { title: "Cổng đặt phòng", subtitle: "Trang khách xem phòng & gửi yêu cầu đặt" },
  requests: { title: "Yêu cầu đặt phòng", subtitle: "Duyệt yêu cầu từ khách trước khi giữ phòng" },
  calendar: { title: "Lịch phòng", subtitle: "Sơ đồ đặt phòng theo ngày" },
  availability: { title: "Tra cứu phòng trống", subtitle: "Tìm phòng theo ngày và số khách" },
  bookings: { title: "Đặt phòng", subtitle: "Quản lý đặt / nhận / trả / hủy phòng" },
  customers: { title: "Khách hàng", subtitle: "Hồ sơ & lịch sử lưu trú" },
  rooms: { title: "Phòng & Loại phòng", subtitle: "Cấu hình phòng, giá, tiện ích" },
  services: { title: "Dịch vụ", subtitle: "Dịch vụ phát sinh & doanh thu" },
  invoices: { title: "Hóa đơn", subtitle: "Lập hóa đơn & theo dõi thanh toán" },
  stats: { title: "Thống kê", subtitle: "Công suất phòng & doanh thu" },
  ai: { title: "Trợ lý AI", subtitle: "Tư vấn phòng, soạn email, phân tích công suất" },
  revenue: { title: "Doanh thu & Giá AI", subtitle: "Dự báo nhu cầu, đề xuất giá, rủi ro no-show" },
  reviews: { title: "Đánh giá khách", subtitle: "Phân tích cảm xúc & cảnh báo chất lượng" },
  channels: { title: "Kênh & OTA", subtitle: "Phân bổ phòng, hoa hồng và đối soát doanh thu" },
  loyalty: { title: "Khách thân thiết", subtitle: "Hạng thành viên, tích điểm và đổi điểm" },
  ops: { title: "Vận hành & Sao lưu", subtitle: "Nhật ký, hiệu năng, email/SMS, sao lưu dữ liệu" },
  profile: { title: "Tài khoản của tôi", subtitle: "Ảnh đại diện, thông tin liên hệ và mật khẩu" },
};

function Shell() {
  const { currentUser } = useStore();
  const [page, setPage] = useState<PageKey>("dashboard");
  // Khách (chưa đăng nhập) vào thẳng cổng đặt phòng công khai;
  // chỉ mở form đăng nhập khi bấm nút "Đăng nhập" (dành cho nhân viên).
  const [showLogin, setShowLogin] = useState(false);

  // Khi đổi user/role, đảm bảo trang hiện tại được phép truy cập
  useEffect(() => {
    if (currentUser && !canAccess(page, currentUser.role)) {
      const first = NAV.find((n) => n.roles.includes(currentUser.role));
      if (first) setPage(first.key);
    }
  }, [currentUser, page]);

  // Đăng nhập thành công → ẩn form login, vào thẳng khu quản trị
  useEffect(() => {
    if (currentUser) setShowLogin(false);
  }, [currentUser]);

  // Khách vãng lai hoặc tài khoản khách (role "guest") → trang công khai;
  // chỉ nhân viên (admin / lễ tân / kế toán) mới vào khu quản trị.
  const isStaff = !!currentUser && currentUser.role !== "guest";
  if (!isStaff) {
    if (showLogin) return <Login onBack={() => setShowLogin(false)} />;
    return <PublicSite onStaffLogin={() => setShowLogin(true)} />;
  }

  const meta = TITLES[page];

  return (
    <Layout page={page} onNavigate={setPage} title={meta.title} subtitle={meta.subtitle}>
      {/* Mỗi trang được bọc riêng: 1 trang lỗi không làm trắng toàn hệ thống */}
      <ErrorBoundary key={page} scope={`page:${page}`}>
      {page === "dashboard" && <Dashboard onNavigate={setPage} />}
      {page === "portal" && <BookingPortal />}
      {page === "requests" && <Requests />}
      {page === "calendar" && <RoomCalendar />}
      {page === "availability" && <Availability />}
      {page === "bookings" && <Bookings />}
      {page === "customers" && <Customers />}
      {page === "rooms" && <Rooms />}
      {page === "services" && <Services />}
      {page === "invoices" && <Invoices />}
      {page === "stats" && <Statistics />}
      {page === "ai" && <AIAssistant />}
      {page === "revenue" && <RevenueAI />}
      {page === "reviews" && <Reviews />}
      {page === "channels" && <Channels />}
      {page === "loyalty" && <Loyalty />}
      {page === "ops" && <Operations />}
      {page === "profile" && <Profile />}
      </ErrorBoundary>
    </Layout>
  );
}

export default function App() {
  return (
    <ErrorBoundary scope="app">
      <I18nProvider>
        <StoreProvider>
          <Shell />
          {/* Cấu hình chi tiết (tự tắt, dàn dọc, tối đa 4 cái) nằm trong components/ui/sonner.tsx */}
          <Toaster position="top-right" duration={1500} />
        </StoreProvider>
      </I18nProvider>
    </ErrorBoundary>
  );
}
