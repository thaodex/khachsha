import { useState } from "react";
import { Building2, CheckCircle2, CreditCard, Loader2, QrCode, ShieldCheck, Wallet } from "lucide-react";
import { Button } from "../ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "../ui/dialog";
import { DEPOSIT_PERCENT, useStore } from "../../lib/store";
import { PAYMENT_METHOD_LABELS } from "../../lib/payments";
import { Booking, PaymentMethod } from "../../lib/types";
import { formatDate, formatVND, nightsBetween } from "../../lib/format";
import { toast } from "sonner";

/** Các cổng khách tự thanh toán được (không gồm tiền mặt — thu tại quầy). */
const GUEST_METHODS: Array<{ method: PaymentMethod; desc: string; instant: boolean }> = [
  { method: "vnpay", desc: "Thẻ ATM / Internet Banking / QR", instant: true },
  { method: "momo", desc: "Ví điện tử MoMo", instant: true },
  { method: "stripe", desc: "Thẻ quốc tế Visa / Mastercard", instant: true },
  { method: "bank_transfer", desc: "Chuyển khoản, lễ tân xác nhận thủ công", instant: false },
];

/**
 * Nội dung thanh toán CỌC GIỮ PHÒNG (20–30% giá trị đặt phòng).
 * Dùng chung cho flow đặt phòng (BookingFlow) và trang "Đặt phòng của tôi".
 */
export function DepositPanel({ booking, onPaid, onOpenLegal }: {
  booking: Booking;
  onPaid?: () => void;
  onOpenLegal?: () => void;
}) {
  const { payDeposit, payDepositWithGateway, roomLabel } = useStore();
  const [method, setMethod] = useState<PaymentMethod>("vnpay");
  const [agreed, setAgreed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const nights = Math.max(nightsBetween(booking.checkIn, booking.checkOut), 1);
  const serviceTotal = booking.services.reduce((s, x) => s + x.price * x.qty, 0);
  const total = booking.roomPricePerNight * nights + serviceTotal;
  const percent = Math.round((booking.depositPercent ?? DEPOSIT_PERCENT) * 100);
  const deposit = booking.depositAmount ?? Math.round(total * DEPOSIT_PERCENT);

  if (booking.depositPaid) {
    return (
      <div className="space-y-3 py-2 text-center">
        <CheckCircle2 className="mx-auto size-12 text-emerald-500" />
        <div className="font-semibold">Đã nhận tiền cọc {formatVND(booking.depositAmount ?? deposit)}</div>
        <p className="text-sm text-muted-foreground">
          Phòng đang được giữ cho bạn. Lễ tân sẽ sớm xác nhận yêu cầu {booking.code}.
        </p>
      </div>
    );
  }

  const chosen = GUEST_METHODS.find((m) => m.method === method)!;

  const pay = async () => {
    if (!agreed) {
      setError("Bạn cần đồng ý điều khoản và chính sách hủy phòng trước khi thanh toán.");
      return;
    }
    setError(null);

    // Chuyển khoản thủ công: khách báo đã CK, lễ tân đối chiếu sau
    if (method === "bank_transfer") {
      payDeposit(booking.id);
      toast.success("Đã ghi nhận báo chuyển khoản " + formatVND(deposit) + ".");
      onPaid?.();
      return;
    }

    setBusy(true);
    try {
      const res = await payDepositWithGateway(booking.id, method);
      if (res.ok) {
        toast.success(res.message);
        onPaid?.();
      } else {
        // Fallback thủ công khi cổng lỗi — khách không bị mắt đặt phòng
        setError(res.message);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Không kết nối được cổng thanh toán.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Bỏ tóm tắt đặt phòng và breakdown vì đã hiển thị ngoài giao diện chính */}

      {/* Chọn phương thức */}
      <div className="space-y-2">
        <div className="text-sm font-medium">Chọn phương thức thanh toán</div>
        <div className="grid gap-2 sm:grid-cols-2">
          {GUEST_METHODS.map((m) => (
            <button
              key={m.method}
              type="button"
              onClick={() => { setMethod(m.method); setError(null); }}
              className={
                "rounded-xl border p-3 text-left text-sm transition-colors " +
                (method === m.method ? "border-primary bg-primary/5 ring-1 ring-primary" : "hover:bg-muted")
              }
            >
              <div className="flex items-center gap-2 font-medium">
                {m.method === "bank_transfer" ? <Building2 className="size-4" /> : <CreditCard className="size-4" />}
                {PAYMENT_METHOD_LABELS[m.method]}
              </div>
              <div className="mt-0.5 text-xs text-muted-foreground">{m.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Thông tin chuyển khoản / QR Code */}
      {method !== "stripe" && (
        <div className="grid gap-3 rounded-xl border p-3 sm:grid-cols-[1fr_auto]">
          <div className="space-y-1 text-sm">
            <div className="inline-flex items-center gap-1.5 font-medium">
              {method === "bank_transfer" ? <Building2 className="size-4" /> : <QrCode className="size-4" />} 
              {method === "momo" ? "Quét mã MoMo" : method === "vnpay" ? "Quét mã VNPay / Ngân hàng" : "Chuyển khoản ngân hàng"}
            </div>
            <div className="text-muted-foreground">MB Bank — Chi nhánh Hà Nội</div>
            <div>STK: <b>0123 456 789</b> — SAO MAI HOTEL</div>
            <div>Số tiền: <b className="text-primary">{formatVND(deposit)}</b></div>
            <div>Nội dung: <b className="text-primary">COC {booking.code}</b></div>
          </div>
          <div className="grid size-28 shrink-0 place-items-center self-center rounded-lg border bg-white p-1">
            <img 
              src={`https://img.vietqr.io/image/MB-0123456789-compact2.png?amount=${deposit}&addInfo=COC%20${booking.code}&accountName=SAO%20MAI%20HOTEL`}
              alt="QR Code thanh toán"
              className="size-full object-contain"
            />
          </div>
        </div>
      )}

      {/* Đồng ý điều khoản */}
      <label className="flex items-start gap-2 text-xs text-muted-foreground">
        <input
          type="checkbox"
          checked={agreed}
          onChange={(e) => { setAgreed(e.target.checked); setError(null); }}
          className="mt-0.5"
        />
        <span>
          Tôi đã đọc và đồng ý{" "}
          {onOpenLegal ? (
            <button type="button" onClick={onOpenLegal} className="text-primary underline">
              điều khoản dịch vụ, chính sách hủy phòng và chính sách bảo mật
            </button>
          ) : (
            <b>điều khoản dịch vụ, chính sách hủy phòng và chính sách bảo mật</b>
          )}
          . Tiền cọc được hoàn theo mốc thời gian hủy ghi trong chính sách.
        </span>
      </label>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
          {error}
          {method !== "bank_transfer" && (
            <div className="mt-1.5 text-xs">
              Bạn có thể thử lại, chọn <b>Chuyển khoản</b>, hoặc gọi hotline để lễ tân giữ phòng thủ công.
            </div>
          )}
        </div>
      )}

      <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
        <ShieldCheck className="mt-0.5 size-3.5 shrink-0" />
        Hệ thống giao dịch bảo mật. Mã QR chứa sẵn số tiền và nội dung, bạn vui lòng không sửa đổi để hệ thống đối soát tự động.
      </p>

      <Button className="w-full" onClick={() => void pay()} disabled={busy}>
        {busy ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle2 className="size-4" />}
        {busy
          ? "Đang xác nhận..."
          : method === "stripe"
            ? "Thanh toán thẻ " + formatVND(deposit)
            : "Tôi đã thanh toán thành công"}
      </Button>
    </div>
  );
}

export function DepositDialog({ booking, onClose, onOpenLegal }: {
  booking: Booking;
  onClose: () => void;
  onOpenLegal?: () => void;
}) {
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Đặt cọc giữ phòng</DialogTitle>
          <DialogDescription>Mã đặt phòng {booking.code}</DialogDescription>
        </DialogHeader>
        <DepositPanel booking={booking} onOpenLegal={onOpenLegal} />
      </DialogContent>
    </Dialog>
  );
}
